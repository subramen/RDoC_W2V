folder "in": the original PsychOpen XML and PDF-files to be processed.
folder "rdf": the RDF-representations of the input PsychOpen articles (the se4ojs output)

Ontologies used for textual content annotation:
ncbo.annotator.ontologies=ONTOAD,NIFSTD,GALEN,SIO,BIOMO,AURA,RADLEX
umls.annotator.ontologies=MSH,PSY,NCI,HL7V3.0,RCD,LNC,CSP,ICNP

UMLS version used by Metamap:
	2013AB -V NLM --relaxed_model
MetaMap processing options:
    -R